import React from "react";
import { createRoot } from "react-dom/client";
import ToggleMessage from "./ToggleMessage.jsx";

const root = createRoot(document.getElementById("root"));
root.render(<ToggleMessage />);
