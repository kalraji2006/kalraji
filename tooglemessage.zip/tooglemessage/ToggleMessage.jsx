import React, { useState } from "react";

export default function ToggleMessage() {
  const [isVisible, setIsVisible] = useState(false);

  const toggle = () => {
    setIsVisible((prev) => !prev);
  };

  return (
    <div style={{ padding: 20 }}>
      <button onClick={toggle}>Show/Hide Message</button>
      {isVisible && <p>Hello, this is a message!</p>}
    </div>
  );
}
