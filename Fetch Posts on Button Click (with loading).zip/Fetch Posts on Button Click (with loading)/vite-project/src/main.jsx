import React from 'react'
import ReactDOM from 'react-dom/client'
import PostsFetcher from './PostsFetcher'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PostsFetcher />
  </React.StrictMode>
)
