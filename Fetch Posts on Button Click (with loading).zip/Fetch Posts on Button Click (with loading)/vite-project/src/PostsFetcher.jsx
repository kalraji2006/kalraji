import React, { useState, useEffect } from 'react'

export default function PostsFetcher() {
  const [shouldFetch, setShouldFetch] = useState(false)
  const [loading, setLoading] = useState(false)
  const [posts, setPosts] = useState([])
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!shouldFetch) return

    setLoading(true)
    setError(null)

    fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok')
        return res.json()
      })
      .then((data) => {
        setPosts(data)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message)
        setLoading(false)
      })
  }, [shouldFetch])

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <button
        onClick={() => setShouldFetch(true)}
        disabled={loading}
        style={{ padding: '0.5rem 1rem', fontSize: '1rem', cursor: 'pointer' }}
      >
        Load Posts
      </button>

      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {posts.length > 0 && (
        <ul style={{ marginTop: '1rem' }}>
          {posts.map((post) => (
            <li key={post.id} style={{ marginBottom: '0.5rem' }}>
              {post.title}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
