import React, { useState } from 'react';

export default function ClickTracker() {
  const [clickCount, setClickCount] = useState(0);

  const handleClick = () => setClickCount(clickCount + 1);

  return (
    <div style={{ textAlign: 'center', marginTop: 50 }}>
      <button onClick={handleClick}>Click me!</button>
      <p>You clicked {clickCount} {clickCount === 1 ? 'time' : 'times'}</p>
    </div>
  );
}
