import React, { useState, useEffect } from 'react'

export default function PersistentInput() {
  const [text, setText] = useState('')

  // Load saved text from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('savedText')
    if (saved) {
      setText(saved)
    }
  }, [])

  // Save text to localStorage on every change
  useEffect(() => {
    localStorage.setItem('savedText', text)
  }, [text])

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <label htmlFor="persistent-input" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Enter text:
      </label>
      <input
        id="persistent-input"
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type something..."
        style={{ padding: '0.5rem', fontSize: '1rem', width: '100%' }}
      />
    </div>
  )
}
