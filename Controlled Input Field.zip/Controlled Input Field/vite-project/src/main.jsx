import React from 'react'
import ReactDOM from 'react-dom/client'
import TextInputDisplay from './TextInputDisplay'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TextInputDisplay />
  </React.StrictMode>
)
