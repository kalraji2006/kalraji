import React from 'react'
import ReactDOM from 'react-dom/client'
import CharacterCounter from './CharacterCounter'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CharacterCounter />
  </React.StrictMode>
)
