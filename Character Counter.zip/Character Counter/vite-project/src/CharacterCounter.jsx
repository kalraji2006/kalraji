import React, { useState } from 'react'

export default function CharacterCounter() {
  const [inputText, setInputText] = useState('')

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <textarea
        placeholder="Type something..."
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        rows={5}
        style={{ width: '100%', padding: '0.5rem', fontSize: '1rem' }}
      />
      <p style={{ marginTop: '1rem' }}>
        Character count: {inputText.length}
      </p>
    </div>
  )
}

