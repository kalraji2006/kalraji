function calculateArea(width: number, height: number): number {
  return width * height;
}

// Valid calls:
const area1 = calculateArea(5, 10);  // 50
console.log(area1);

const area2 = calculateArea(7.5, 3.2);  // 24
console.log(area2);

