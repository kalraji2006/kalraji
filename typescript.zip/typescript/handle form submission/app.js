function handleFormSubmit(event) {
    event.preventDefault();
    var form = event.target;
    var nameInput = form.elements.namedItem("name");
    var emailInput = form.elements.namedItem("email");
    console.log("Name:", nameInput.value);
    console.log("Email:", emailInput.value);
}
window.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById("userForm");
    if (form) {
        form.addEventListener("submit", handleFormSubmit);
    }
    else {
        console.warn('Form with id="userForm" not found.');
    }
});
