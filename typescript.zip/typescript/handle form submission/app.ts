function handleFormSubmit(event: Event): void {
  event.preventDefault();

  const form = event.target as HTMLFormElement;
  const nameInput = form.elements.namedItem("name") as HTMLInputElement;
  const emailInput = form.elements.namedItem("email") as HTMLInputElement;

  console.log("Name:", nameInput.value);
  console.log("Email:", emailInput.value);
}

window.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("userForm") as HTMLFormElement | null;
  if (form) {
    form.addEventListener("submit", handleFormSubmit);
  } else {
    console.warn('Form with id="userForm" not found.');
  }
});
