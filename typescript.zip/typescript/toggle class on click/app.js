function toggleClass() {
    var box = document.getElementById("box");
    if (box) {
        box.classList.toggle("active");
    }
    else {
        console.warn('Element with id="box" not found.');
    }
}
// Attach event listener to button after DOM loaded
window.addEventListener("DOMContentLoaded", function () {
    var button = document.getElementById("toggleBtn");
    if (button) {
        button.addEventListener("click", toggleClass);
    }
    else {
        console.warn('Button with id="toggleBtn" not found.');
    }
});
