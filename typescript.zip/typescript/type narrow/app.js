function printValue(value) {
    var outputElement = document.getElementById('output');
    if (typeof value === 'string') {
        console.log(value.toUpperCase());
        if (outputElement) {
            outputElement.textContent += "String uppercase: ".concat(value.toUpperCase(), "\n");
        }
    }
    else if (typeof value === 'number') {
        console.log(value * 2);
        if (outputElement) {
            outputElement.textContent += "Number multiplied by 2: ".concat(value * 2, "\n");
        }
    }
}
// Test the function
printValue("hello");
printValue(21);
