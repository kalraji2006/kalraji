function openModal(): void {
  const modal = document.getElementById("modal");
  if (modal) {
    modal.style.display = "block";
  }
}

function closeModal(): void {
  const modal = document.getElementById("modal");
  if (modal) {
    modal.style.display = "none";
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const openBtn = document.getElementById("openModalBtn");
  const closeBtn = document.getElementById("closeBtn");

  if (openBtn) {
    openBtn.addEventListener("click", openModal);
  } else {
    console.warn('Open modal button not found.');
  }

  if (closeBtn) {
    closeBtn.addEventListener("click", closeModal);
  } else {
    console.warn('Close modal button not found.');
  }

  // Optional: close modal when clicking outside modal content
  const modal = document.getElementById("modal");
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });
  }
});
