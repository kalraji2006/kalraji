function openModal() {
    var modal = document.getElementById("modal");
    if (modal) {
        modal.style.display = "block";
    }
}
function closeModal() {
    var modal = document.getElementById("modal");
    if (modal) {
        modal.style.display = "none";
    }
}
window.addEventListener("DOMContentLoaded", function () {
    var openBtn = document.getElementById("openModalBtn");
    var closeBtn = document.getElementById("closeBtn");
    if (openBtn) {
        openBtn.addEventListener("click", openModal);
    }
    else {
        console.warn('Open modal button not found.');
    }
    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }
    else {
        console.warn('Close modal button not found.');
    }
    // Optional: close modal when clicking outside modal content
    var modal = document.getElementById("modal");
    if (modal) {
        modal.addEventListener("click", function (e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    }
});
