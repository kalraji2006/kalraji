function calculateArea(width, height) {
    return width * height;
}
// Valid calls:
var area1 = calculateArea(5, 10); // 50
console.log(area1);
var area2 = calculateArea(7.5, 3.2); // 24
console.log(area2);
