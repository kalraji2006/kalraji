function calculateArea(width, height) {
    return width * height;
}
// Valid calls
var area1 = calculateArea(5, 10);
var area2 = calculateArea(7.5, 3.2);
// Invalid calls (uncomment to see TypeScript errors)
// const area3 = calculateArea("5", 10);
// const area4 = calculateArea(5, null);
// Show results on page
var output = document.getElementById("output");
output.innerHTML = "\n  <strong>Area 1 (5 x 10):</strong> ".concat(area1, " <br />\n  <strong>Area 2 (7.5 x 3.2):</strong> ").concat(area2.toFixed(2), "\n");
