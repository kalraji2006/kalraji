function calculateArea(width: number, height: number): number {
  return width * height;
}

// Valid calls
const area1 = calculateArea(5, 10);
const area2 = calculateArea(7.5, 3.2);

// Invalid calls (uncomment to see TypeScript errors)
// const area3 = calculateArea("5", 10);
// const area4 = calculateArea(5, null);

// Show results on page
const output = document.getElementById("output")!;
output.innerHTML = `
  <strong>Area 1 (5 x 10):</strong> ${area1} <br />
  <strong>Area 2 (7.5 x 3.2):</strong> ${area2.toFixed(2)}
`;
