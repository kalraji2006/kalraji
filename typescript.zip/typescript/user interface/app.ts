interface User {
  id: number;
  name: string;
  isActive: boolean;
}

function printUser(user: User): void {
  const userInfo = `User Info:
ID: ${user.id}
Name: ${user.name}
Active: ${user.isActive ? "Yes" : "No"}`;

  // Log to console
  console.log(userInfo);

  // Also show on page
  const output = document.getElementById("output");
  if (output) {
    output.textContent = userInfo;
  }
}

const sampleUser: User = {
  id: 1,
  name: "Alice",
  isActive: true,
};

printUser(sampleUser);
