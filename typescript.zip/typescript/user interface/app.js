function printUser(user) {
    var userInfo = "User Info:\nID: ".concat(user.id, "\nName: ").concat(user.name, "\nActive: ").concat(user.isActive ? "Yes" : "No");
    // Log to console
    console.log(userInfo);
    // Also show on page
    var output = document.getElementById("output");
    if (output) {
        output.textContent = userInfo;
    }
}
var sampleUser = {
    id: 1,
    name: "Alice",
    isActive: true,
};
printUser(sampleUser);
