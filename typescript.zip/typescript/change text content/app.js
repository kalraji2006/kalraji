function updateGreeting(text) {
    var greetingElement = document.getElementById("greeting");
    if (greetingElement) {
        greetingElement.textContent = text;
    }
    else {
        console.warn('Element with id="greeting" not found.');
    }
}
// Call the function with a custom greeting
updateGreeting("Hello, welcome to TypeScript!");
