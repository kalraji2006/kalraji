type Product = {
  id: number;
  name: string;
  price: number;
};

const products: Product[] = [
  { id: 1, name: "Laptop", price: 1200 },
  { id: 2, name: "Smartphone", price: 800 },
  { id: 3, name: "Headphones", price: 150 },
];

function logProducts(products: Product[]): void {
  const output = document.getElementById("output");
  products.forEach((product) => {
    const line = `Product: ${product.name}, Price: $${product.price}\n`;
    console.log(line);
    if (output) {
      output.textContent += line;
    }
  });
}

logProducts(products);

