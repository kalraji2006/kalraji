var products = [
    { id: 1, name: "Laptop", price: 1200 },
    { id: 2, name: "Smartphone", price: 800 },
    { id: 3, name: "Headphones", price: 150 },
];
function logProducts(products) {
    var output = document.getElementById("output");
    products.forEach(function (product) {
        var line = "Product: ".concat(product.name, ", Price: $").concat(product.price, "\n");
        console.log(line);
        if (output) {
            output.textContent += line;
        }
    });
}
logProducts(products);
