import React, { useState, useEffect } from 'react'

export default function ThemeToggler() {
  const [theme, setTheme] = useState('light')

  // On mount, read theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme')
    if (savedTheme === 'light' || savedTheme === 'dark') {
      setTheme(savedTheme)
    }
  }, [])

  // On theme change, save to localStorage
  useEffect(() => {
    localStorage.setItem('theme', theme)
    // Optionally, update document body class for styling
    document.body.className = theme === 'dark' ? 'dark-theme' : 'light-theme'
  }, [theme])

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))
  }

  // Basic inline styles for demo
  const styles = {
    container: {
      padding: '2rem',
      fontFamily: 'Arial, sans-serif',
      backgroundColor: theme === 'dark' ? '#222' : '#fff',
      color: theme === 'dark' ? '#eee' : '#111',
      minHeight: '100vh',
      transition: 'background-color 0.3s, color 0.3s',
    },
    button: {
      padding: '0.5rem 1rem',
      fontSize: '1rem',
      cursor: 'pointer',
      marginTop: '1rem',
    },
  }

  return (
    <div style={styles.container}>
      <h2>Theme Toggler</h2>
      <p>Current theme: <strong>{theme}</strong></p>
      <button onClick={toggleTheme} style={styles.button}>
        Toggle Theme
      </button>
    </div>
  )
}
