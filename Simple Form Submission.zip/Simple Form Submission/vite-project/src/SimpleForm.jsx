import React, { useState } from 'react'

export default function SimpleForm() {
  const [name, setName] = useState('')
  const [submittedName, setSubmittedName] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault() // prevent page reload
    setSubmittedName(name)
    setName('') // clear input after submission
  }

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={{ padding: '0.5rem', fontSize: '1rem', marginRight: '0.5rem' }}
        />
        <button type="submit" style={{ padding: '0.5rem 1rem', fontSize: '1rem' }}>
          Submit
        </button>
      </form>
      {submittedName && (
        <p style={{ marginTop: '1rem', fontWeight: 'bold' }}>
          Submitted: {submittedName}
        </p>
      )}
    </div>
  )
}
